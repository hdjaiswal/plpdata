﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{
   public class JobseekersOperations
   {
       SqlDataReader reader;
       int result;
       DataTable jsTable = new DataTable();
  
       
         public bool AddJobSeekerPDetails(Jobseeker js)
         {
             bool jsAdded = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddJobseekers";
               
                
                 cmdAdd.Parameters.AddWithValue("@FirstName ", js.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", js.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", js.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", js.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", js.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", js.JPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", js.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", js.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", js.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", js.JMaritalStatus);
               
                
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
                

                 if (result > 0)
                     jsAdded = true;
                 
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             return jsAdded;
         }

         public bool UpdatePersonalDetails(Jobseeker jsObj)
         {
             bool pedUpdated = false;
             try
             {
                 SqlCommand cmdupdate = DataConfiguration.CreateCommand();

                 cmdupdate.CommandText = "ORSGroup6.UpdatePersonalDetails";
                 
            
                 cmdupdate.Parameters.AddWithValue("@JobSeekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@FirstName", jsObj.JFirstName);
                 cmdupdate.Parameters.AddWithValue("@LastName", jsObj.JLastName);
                 cmdupdate.Parameters.AddWithValue("@MiddleName", jsObj.JMiddleName);
                 cmdupdate.Parameters.AddWithValue("@ContactNo", jsObj.JPhoneNo);
                 cmdupdate.Parameters.AddWithValue("@Gender", jsObj.JGender);
                 cmdupdate.Parameters.AddWithValue("@MarraigeStatus", jsObj.JMaritalStatus);
                 cmdupdate.Parameters.AddWithValue("@JobSeekersAddress", jsObj.JAddress);
                 cmdupdate.Parameters.AddWithValue("@DOB", jsObj.JDOB);
               
                 cmdupdate.Connection.Open();
                 result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Close();

                 if (result > 0)
                     pedUpdated = true;
                
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             return pedUpdated;
         }

         public bool UpdateProfessionalDetails(Jobseeker jsObj)
         {
             bool profUpdated = false;
             try
             {
                 SqlCommand cmdupdate = DataConfiguration.CreateCommand();

                 cmdupdate.CommandText = "ORSGroup6.UpdateProfesionalDetails";
              
               
                 cmdupdate.Parameters.AddWithValue("@jobseekerId", jsObj.JobSeekerID);
                 cmdupdate.Parameters.AddWithValue("@CurrentDesignation", jsObj.JCurrentDesig);
                 cmdupdate.Parameters.AddWithValue("@PrimarySkills", jsObj.JPrimarySkills);
                 cmdupdate.Parameters.AddWithValue("@SecondarySkills", jsObj.JSecondarySkills);
                 cmdupdate.Parameters.AddWithValue("@TrainingAttended", jsObj.JTrainingAttd);
                 cmdupdate.Parameters.AddWithValue("@Designation", jsObj.JDesignation);
                 cmdupdate.Parameters.AddWithValue("@Location", jsObj.DJobLocation);
                 cmdupdate.Parameters.AddWithValue("@Experience", jsObj.JExperience);

                
                 cmdupdate.Connection.Open();
                 result = cmdupdate.ExecuteNonQuery();
                 cmdupdate.Connection.Close();

                 if (result > 0)
                     profUpdated = true;
                 
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return profUpdated;
         }

         public DataTable SearchByLocation(string jobloc)
         {
             try
             {
                 SqlCommand cmdsrchloc = DataConfiguration.CreateCommand();

                 cmdsrchloc.CommandText = "ORSGroup6.SearchbyLocation";
                 cmdsrchloc.Parameters.AddWithValue("@JobLocation", jobloc);
                 cmdsrchloc.Connection.Open();
                 reader = cmdsrchloc.ExecuteReader();
                 reader.Read();
                 jsTable.Load(reader);
                 cmdsrchloc.Connection.Close(); 
             }

             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }

         public DataTable SearchByDesignation(string jobdesig)
         {
             try
             {
                 SqlCommand cmdsrchdesig = DataConfiguration.CreateCommand();

                 cmdsrchdesig.CommandText = "ORSGroup6.SearchbyDesignation";
                 cmdsrchdesig.Parameters.AddWithValue("@Designation", jobdesig);
                 cmdsrchdesig.Connection.Open();
                 reader = cmdsrchdesig.ExecuteReader();
                 jsTable.Load(reader);
                 cmdsrchdesig.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }

         public DataTable SearchByExperience(string jexp)
         {
             try
             {
                 SqlCommand cmdsrcexp = DataConfiguration.CreateCommand();

                 cmdsrcexp.CommandText = "ORSGroup6.SearchbyExperience";

                 cmdsrcexp.Parameters.AddWithValue("@Experience", jexp);

                 if (cmdsrcexp.Connection.State == ConnectionState.Closed)
                     cmdsrcexp.Connection.Open();
                 reader = cmdsrcexp.ExecuteReader();
                 jsTable.Load(reader);
                 cmdsrcexp.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }

        public static string ValidateLogin(Jobseeker user)
        {
            string userName = null;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.JobSeekerVerification";

                cmd.Parameters.AddWithValue("@EmailAddress", user.JEmailAddress);
                cmd.Parameters.AddWithValue("@Password", user.JPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
              
                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr[0].ToString();
                }
                cmd.Connection.Close();
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }

        public static int GetJobSeekerID(Jobseeker jsuser)
        {
            int jsid=0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.GetJobSeekeID";

                cmd.Parameters.AddWithValue("@EmailAddress", jsuser.JEmailAddress);
                cmd.Parameters.AddWithValue("@Password", jsuser.JPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    jsid = Convert.ToInt32(dr[0]);
                }

                cmd.Connection.Close();
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return jsid;
        }
   


         public bool AddJobSeekerQDetails(Jobseeker jsObj)
         {
             bool jsAdded = false;
             try
             {
                
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();
                 cmdAdd.CommandText = "ORSGroup6.JobseekersQualificationDetail";
                 
                 cmdAdd.Parameters.AddWithValue("@Degree", jsObj.Degree);
                 cmdAdd.Parameters.AddWithValue("@Branch", jsObj.Branch);
                 cmdAdd.Parameters.AddWithValue("@Passingyear", jsObj.PassingYr);
                 cmdAdd.Parameters.AddWithValue("@Percentage", jsObj.Percentage);
                 cmdAdd.Parameters.AddWithValue("@UniversityName", jsObj.UniversityName);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jsObj.JobSeekerID);
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
        
                 if (result > 0)
                     jsAdded = true;
                 
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jsAdded;
         }

         public bool ApplyJobs(Jobseeker jobj)
         {
             bool jobsApplied = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.ApplyJobs";
                 cmdAdd.Parameters.AddWithValue("@JobId", jobj.JobID);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerId", jobj.JobSeekerID);

               
                 cmdAdd.Connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jobsApplied = true;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jobsApplied;
         }  
       
         public DataTable GetAppliedDetails(int jsid)
         {
             DataTable jobTable = new DataTable();
             try
             {
                 SqlCommand cmdgetjapldetails = DataConfiguration.CreateCommand();

                 cmdgetjapldetails.CommandText = "ORSGroup6.ViewAppliedJobs";
                 cmdgetjapldetails.Parameters.AddWithValue("@JobSeekerId", jsid);


                 cmdgetjapldetails.Connection.Open();
                 reader = cmdgetjapldetails.ExecuteReader();

                 reader.Read();
               
                 jobTable.Load(reader);
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jobTable;
         }

         public DataTable GetQualificationDetails(int jsid)
         {
             try
             {
                 SqlCommand cmdGetqdetails = DataConfiguration.CreateCommand();

                 cmdGetqdetails.CommandText = "ORSGroup6.GetQualificationDetails";
                 cmdGetqdetails.Parameters.AddWithValue("@jobseekerid ", jsid);

                 cmdGetqdetails.Connection.Open();
                 reader = cmdGetqdetails.ExecuteReader();

                 jsTable.Load(reader);
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jsTable;
         }

         public static Jobseeker SearchPDetails(int jsid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchPersonalDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerID", jsid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.JobSeekerID = Convert.ToInt32(dr["JobSeekerID"]);
                     js.JFirstName = dr["FirstName"].ToString();
                     js.JMiddleName = dr["MiddleName"].ToString();
                     js.JLastName = dr["LastName"].ToString();
                     js.JDOB = Convert.ToDateTime(dr["DOB"]);
                     js.JGender = dr["Gender"].ToString();
                     js.JPhoneNo=Convert.ToInt64(dr["ContactNo"]);
                     js.JAddress=dr["JobSeekersAddress"].ToString();
                     js.JMaritalStatus=dr["MarraigeStatus"].ToString();
                 }
                 
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return js;
         }

         public static Jobseeker SearchQDetailsByQID(int qid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchQDetailsByQID";

                 cmd.Parameters.AddWithValue("@qid", qid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.QualificationID = Convert.ToInt32(dr["QualificationID"]);
                     js.UniversityName = dr["UniversityName"].ToString();
                     js.Degree = dr["Degree"].ToString();
                     js.Branch = dr["Branch"].ToString();
                     js.PassingYr = Convert.ToInt32(dr["PassingYear"]);
                     js.Percentage=Convert.ToDouble(dr["Percentage"]);
                 }
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return js;
         }

         public bool AddJobSeekerPrDetails(Jobseeker jsObj)
         {
             bool jsAdded = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddProfessionaDetails";
                
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jsObj.JobSeekerID);
                 cmdAdd.Parameters.AddWithValue("@CurrentDesignation", jsObj.JCurrentDesig);
                 cmdAdd.Parameters.AddWithValue("@PrimarySkills", jsObj.JPrimarySkills);
                 cmdAdd.Parameters.AddWithValue("@SecondarySkills", jsObj.JSecondarySkills);
                 cmdAdd.Parameters.AddWithValue("@TrainingAttended", jsObj.JTrainingAttd);
                 cmdAdd.Parameters.AddWithValue("@Designation", jsObj.JDesignation);
                 cmdAdd.Parameters.AddWithValue("@Location", jsObj.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Experience", jsObj.JExperience);

                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jsAdded = true;
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             return jsAdded;
         }

         public static Jobseeker SearchProfDetails(int jsid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchJSProfDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerID", jsid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.JobSeekerID = Convert.ToInt32(dr["JobSeekerID"]);
                     js.JPrimarySkills = dr["PrimarySkills"].ToString();
                     js.JSecondarySkills = dr["SecondarySkills"].ToString();
                     js.JTrainingAttd = dr["TrainingAttended"].ToString();
                     js.JCurrentDesig = dr["CurrentDesignation"].ToString();
                     js.JExperience = dr["Experience"].ToString();
                     js.DJobLocation = dr["Location"].ToString();
                     js.JDesignation = dr["Designation"].ToString();
                     
                 }
                
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return js;
         }

         public static int UpdatePdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGroup6.UpdatePersonalDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerId", js.JobSeekerID);
                 cmd.Parameters.AddWithValue("@FirstName", js.JFirstName);
                 cmd.Parameters.AddWithValue("@LastName", js.JLastName);
                 cmd.Parameters.AddWithValue("@MiddleName", js.JMiddleName);
                 cmd.Parameters.AddWithValue("@ContactNo", js.JPhoneNo);
                 cmd.Parameters.AddWithValue("@Gender", js.JGender);
                 cmd.Parameters.AddWithValue("@MarraigeStatus", js.JMaritalStatus);
                 cmd.Parameters.AddWithValue("@JobSeekersAddress", js.JAddress);
                 cmd.Parameters.AddWithValue("@DOB", js.JDOB);

                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }

         public static int UpdateProfdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGroup6.UpdateProfesionalDetails";

                 cmd.Parameters.AddWithValue("@jobseekerId", js.JobSeekerID);
                 cmd.Parameters.AddWithValue("@CurrentDesignation", js.JCurrentDesig);
                 cmd.Parameters.AddWithValue("@PrimarySkills", js.JPrimarySkills);
                 cmd.Parameters.AddWithValue("@SecondarySkills", js.JSecondarySkills);
                 cmd.Parameters.AddWithValue("@TrainingAttended", js.JTrainingAttd);
                 cmd.Parameters.AddWithValue("@Designation", js.JDesignation);
                 cmd.Parameters.AddWithValue("@Location", js.DJobLocation);
                 cmd.Parameters.AddWithValue("@Experience", js.JExperience);
                
                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }


         public static int UpdateQdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGROUP6.UpdateQualificationDetails";

                 cmd.Parameters.AddWithValue("@QualificationID", js.QualificationID);
                 cmd.Parameters.AddWithValue("@Degree", js.Degree);
                 cmd.Parameters.AddWithValue("@Branch", js.Branch);
                 cmd.Parameters.AddWithValue("@Percentage", js.Percentage);
                 cmd.Parameters.AddWithValue("@PassingYear", js.PassingYr);
                 cmd.Parameters.AddWithValue("@UniversityName", js.UniversityName);
                 cmd.Parameters.AddWithValue("@JobSeekerID", js.JobSeekerID);

                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }
    }
}
