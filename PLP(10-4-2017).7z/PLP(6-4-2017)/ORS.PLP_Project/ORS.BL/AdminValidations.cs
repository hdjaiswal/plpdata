﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;


namespace ORS.BL
{
    public class AdminValidations
    {
        public static string ValidateAdmin(AdminEntity user)
        {
            string userName = null;

            try
            {
                userName = AdminOperations.ValidateAdmin(user);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userName;
        }

        AdminOperations adminObj = new AdminOperations();

        public DataTable GetJobDetails()
        {
            DataTable jobTable = new DataTable();
            try
            {
                jobTable = adminObj.GetJobDetails();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }

        public static int DeleteExpJobs(int jobID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = AdminOperations.DeleteExpJobs(jobID);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
