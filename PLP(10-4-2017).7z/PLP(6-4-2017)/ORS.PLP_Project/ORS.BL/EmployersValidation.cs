﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ORS.BL
{
    public class EmployersValidation
    {
        EmployerOperations empOp = new EmployerOperations();

        public bool AddEmployeeDetails(Employer jobj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = empOp.AddEmployeeDetails(jobj);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        public bool AddJobs(Employer jobj)
        {
            bool jobsAdded = false;
            try
            {
                jobsAdded = empOp.AddJobs(jobj);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobsAdded;
        }
       
        public DataTable GetPostedJobs(int empid)
        {

            DataTable jobTable = new DataTable();
            try
            {
                jobTable = empOp.GetPostedJobs(empid);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }

        public DataTable GetJobApplications(int empid, int jobid)
        {
            DataTable jobTable = new DataTable();
            try
            {
                jobTable = empOp.GetJobApplications(empid, jobid);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jobTable;
        }


        public static string ValidateUser(Employer user)
        {
            string empemail = null;
            
            try
            {
                empemail = EmployerOperations.ValidateLogin(user);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empemail;
        }

        public static int GetEmployeeID(Employer user)
        {
            int empid=0;

            try
            {
                empid = EmployerOperations.GetEmployeeID(user);
            }
            catch (EmployersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empid;
        }
    }
}
