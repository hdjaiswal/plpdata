﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ORS.BL
{
   public class JobseekersValidation
    {
    JobseekersOperations jsOp = new JobseekersOperations();

        public bool AddJobSeekerPDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerPDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        public bool AddJobSeekerQDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerQDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        public bool AddJobSeekerPrDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerPrDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        public bool ApplyJobs(Jobseeker jobj)
        {
            bool jsApplied = false;
            try
            {
                jsApplied = jsOp.ApplyJobs(jobj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsApplied;
        }

        public DataTable GetAppliedDetails(int jsid)
        {

            DataTable jappTable = new DataTable();
            try
            {
                jappTable = jsOp.GetAppliedDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jappTable;
        }

        public DataTable GetQualificationDetails(int jsid)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.GetQualificationDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        public static Jobseeker SearchPDetails(int jsid)
        {
            Jobseeker js = null;
            try
            {
                js = JobseekersOperations.SearchPDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return js;
        }

        public static Jobseeker SearchProfDetails(int jsid)
        {
            Jobseeker js = null;

            try
            {
                js = JobseekersOperations.SearchProfDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return js;
        }


        public static Jobseeker SearchQDetailsByQID(int qid)
        {
            Jobseeker js = null;

            try
            {
                js =JobseekersOperations.SearchQDetailsByQID(qid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return js;
        }

        public static int UpdatePdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdatePdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }


        public static int UpdateProfdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdateProfdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }


        public static int UpdateQdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdateQdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }

       
        public bool UpdatePersonalDetails(Jobseeker jsObj)
        {
            bool pedUpdated = false;
            try
            {
                pedUpdated = jsOp.UpdatePersonalDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return pedUpdated;
        }

        public bool UpdateProfessionalDetails(Jobseeker jsObj)
        {
            bool profUpdated = false;
            try
            {
                profUpdated = jsOp.UpdateProfessionalDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return profUpdated;
        }

        public DataTable SearchByLocation(string jobloc)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByLocation(jobloc);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        public DataTable SearchByDesignation(string jobdesig)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByDesignation(jobdesig);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        public DataTable SearchByExperience(string jexp)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByExperience(jexp);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        public static string ValidateLogin(Jobseeker user)
        {
            string userName = null;

            try
            {
                userName = JobseekersOperations.ValidateLogin(user);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }

        public static int GetJobSeekerID(Jobseeker jsuser)
        {
            int jsid =0;

            try
            {
                jsid = JobseekersOperations.GetJobSeekerID(jsuser);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

           return jsid;
        }
    }
}
