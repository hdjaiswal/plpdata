﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLibrary
{

    /// <summary>
    /// Class to throw Jobseekers exception
    /// Author: 
    /// Date Modified: 5th April 2017
    /// Version No:
    /// Change Description:
    /// </summary>
   public class JobseekersException:ApplicationException
    {
       public JobseekersException()
           : base() 
       { }
       public JobseekersException(string message)
           : base() 
       { }

    }
}
