﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    /// <summary>
    /// Entity to store Employer's Information
    /// Author: Gayatri Yadkikar
    /// Date Modified: 5th April 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public  class Employer
    {
        /// <summary>
        /// Property to store and retrieve Employer's ID
        /// </summary>
        public int EmployeeID { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's First name
        /// </summary>
        public string EFirstName { get; set; }

        //public string EMiddleName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's LastName
        /// </summary>
        public string ELastName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Company name
        /// </summary>
        public string ECompanyName { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Email-address
        /// </summary>
        public string EEmailAddress { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Designation
        /// </summary>
        public string EDesignation { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Location
        /// </summary>
        public string ELocation { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's Phone no
        /// </summary>
        public Int64 EPhoneNo { get; set; }
        /// <summary>
        /// Property to store and retrieve Employer's  Password
        /// </summary>
        public string EPassword { get; set; }



        public int EJobID { get; set; }
        public string DCompanyName { get; set; }
        public string DPost { get; set; }
        public int DVacancies { get; set; }
        public DateTime DPostedDate { get; set; }
        public DateTime DLastDate { get; set; }
        public string DDescription { get; set; }
        public Double DPackage { get; set; }
        public string DJobLocation { get; set; }
        public string DExperience { get; set; }
    }
}
 