﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    public partial class AppliedJobs : System.Web.UI.Page
    {

        JobseekersValidation validationObj = new JobseekersValidation();

        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = "Welcome " + Session["user"];
            lbljsid.Text = "Your ID :" + Session["jsid"];
            Master.LogoutVisible = true;

            if (!IsPostBack)
            {
                DataTable jobTable = new DataTable();
                int jobid = Convert.ToInt32(Session["jsid"]);
                jobTable = validationObj.GetAppliedDetails(jobid);

                grdappliedjobs.DataSource = jobTable;
                grdappliedjobs.DataBind();
            } 
        }
    }
}