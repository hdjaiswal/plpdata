﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace WebApplication2
{
    public partial class SearchJobs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                lblUser.Text = "Welcome " + Session["user"];
                lbljsid.Text = "Your ID :" + Session["jsid"];
                Master.LogoutVisible = true;
        }

        JobseekersValidation validationObj = new JobseekersValidation();
        Jobseeker jsObj = new Jobseeker();

        protected void btnExpSearch_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable jsTable = new DataTable();
                string jexp = ddlexp.Text;
                jsTable = validationObj.SearchByExperience(jexp);
                if (jsTable.Rows.Count>0)
                {
                    gvsrchjob.DataSource = jsTable;
                    gvsrchjob.DataBind();
                }
                else
                {
                    Response.Write("<script>alert('No Jobs Available')</script>");
                }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDesigSearch_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable jsTable = new DataTable();
                string post = txtdesig.Text;
                jsTable = validationObj.SearchByDesignation(post);
                if (jsTable.Rows.Count > 0)
                {
                    gvsrchjob.DataSource = jsTable;
                    gvsrchjob.DataBind();
                }
                else
                {
                    Response.Write("<script>alert('No Jobs Avaliable')</script>");
                }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnLoctnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable jsTable = new DataTable();
                string loc = txtloc.Text;
                jsTable = validationObj.SearchByLocation(loc);
                if (jsTable.Rows.Count>0)
                {
                    gvsrchjob.DataSource = jsTable;
                    gvsrchjob.DataBind();
                }
                else
                {
                    Response.Write("<script>alert('No Jobs Avaliable')</script>");
                }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                jsObj.JobSeekerID = Convert.ToInt32(Session["jsid"]);
                jsObj.JobID = Convert.ToInt32(txtSrchJId.Text);

                validationObj.ApplyJobs(jsObj);
                Response.Write("<script>alert('Job Applied Successfully')</script>");
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}