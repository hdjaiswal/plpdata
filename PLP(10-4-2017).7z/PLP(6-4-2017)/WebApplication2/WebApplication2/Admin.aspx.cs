﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ORS.BL;
using ORS.ExceptionLibrary;
using ORS.Entity;


namespace WebApplication2
{
    public partial class Admin : System.Web.UI.Page
    {
        AdminValidations validationObj = new AdminValidations();

        protected void Page_Load(object sender, EventArgs e)
        {
                lblUser.Text = "Hello " + Session["user"];
                Master.LogoutVisible = true;
                if (!IsPostBack)
                {
                    DataTable jobTable = new DataTable();
                    jobTable = validationObj.GetJobDetails();
                    gvjobdetails.DataSource = jobTable;
                    gvjobdetails.DataBind();
                }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                int jobID = Convert.ToInt32(txtexpjobid.Text);
                int recordsAffected = AdminValidations.DeleteExpJobs(jobID);
                if (recordsAffected > 0)
                {
                    Response.Redirect("Admin.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Job ID not found')</script>");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}