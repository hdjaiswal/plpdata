﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;


namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        EmployersValidation validationObj = new EmployersValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

            lbluser.Text = "Welcome " + Session["user"];
            lblempid.Text = "Your ID " + Session["empid"];
            Master.LogoutVisible = true;
            try
            {
                DataTable postjobTable = new DataTable();
                int empid = Convert.ToInt32(Session["empid"]);

                postjobTable = validationObj.GetPostedJobs(empid);
                if (postjobTable.Rows.Count > 0)
                {
                    gvpostedjobs.DataSource = postjobTable;
                    gvpostedjobs.DataBind();
                }
                else
                    Response.Write("<script>alert('Data is not available')</script>");
            }
            catch (EmployersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}